insert into book values (1, 'Suzanne Collins','The Hunger Games',12,3,0);
insert into book values (2,  'J.K. Rowling','Harry Potter Series Box Set',14,5,0);
insert into book values (3,  'Stephenie Meyer','Twilight',35,1,0);
insert into book values (4,  'Jane Austen','Pride and Prejudice',8,0,0);
insert into book values (5,  'Harper Lee','To Kill a Mockingbird',75,20,0);
insert into book values (6,  'J.R.R. Tolkien','The Hobbit, or There and Back Again',28,45,0);
insert into book values (7,  'Markus Zusak','The Book Thief',8,0,0);
insert into book values (8,  'Jane Austen','Pride and Prejudice 2',8,0,0);
