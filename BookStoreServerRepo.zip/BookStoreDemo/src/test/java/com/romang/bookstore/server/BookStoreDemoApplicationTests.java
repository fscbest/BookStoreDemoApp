package com.romang.bookstore.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookStoreDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
