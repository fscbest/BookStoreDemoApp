import { Component, OnInit } from '@angular/core';
import { BookstoreserviceService } from '../bookstoreservice.service';
import { Router } from '@angular/router';
import { Book } from '../book';
import { NgForm } from '@angular/forms';
 
@Component({
  selector: 'app-addbook',
  templateUrl: './addbook.component.html',
  styleUrls: ['./addbook.component.css']
})
export class AddbookComponent implements OnInit {

  book = new Book();
  constructor(private _route:Router, private _service:BookstoreserviceService) { }

  ngOnInit(): void {
  }

  addBookformsubmit(){
    this._service.addBook(this.book).subscribe
    (
      data =>{
        console.log("Data added successfully");
        this._route.navigate(['booklist']);
      },
      error =>console.log("Error")
    )
    }
    
    
  gotolist() {
    this._route.navigate(['booklist']);
  }
}
