import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BooklistComponent } from './booklist/booklist.component';
import { AddbookComponent } from './addbook/addbook.component';
import { BuybookComponent } from './buybook/buybook.component';
import { EditbookComponent } from './editbook/editbook.component';

const routes: Routes = [
  {path:'', component:BooklistComponent},
  {path:'booklist', component:BooklistComponent},
  {path:'addbook', component:AddbookComponent},
  {path:'buybook', component:BuybookComponent},
  {path:'buybook/:id', component:BuybookComponent},
  {path:'editbook', component:EditbookComponent},
  {path:'editbook/:id', component:EditbookComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
