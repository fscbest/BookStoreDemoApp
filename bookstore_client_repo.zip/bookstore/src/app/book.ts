export class Book {
    id: number;
    name: string;
    author: string;
    price: number;
    quantity: number;
}
