import { Component, OnInit } from '@angular/core';
import { BookstoreserviceService } from '../bookstoreservice.service';
import { Router } from '@angular/router';
import { Book } from '../book';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {

  _bookList : Array<Book> = [];
  _nameToSearch : string;
  constructor(private _service:BookstoreserviceService,
              private _route:Router) { }

  ngOnInit(): void {
    this.getBooks();
  }

  getBooks() {
    this._service.fetchBookList().subscribe(
      data => this._bookList = data, error => console.log("Exception occurred 1"),
    )
  }

  clearTheSearchCriteria(){
    this._nameToSearch = '';
    this.getBooks();
  }
  isEmpty()
  {
    if (this._bookList == null)
    {
      return true;
    }
    else { return false; }
  }

  goToAddBook(){
    this._route.navigate(['/addbook']);
  }

  goToBuyBook(id:number){
    this._route.navigate(['/buybook', id]);
  }

  goToUpdateBook(id:number){
    this._route.navigate(['/editbook', id]);
  }

  goToSearchByName(){
    this._service.searchBookByName(this._nameToSearch).subscribe(
      data => this._bookList = data, error => console.log("Exception occurred 1"),
    )
  }
  
}
