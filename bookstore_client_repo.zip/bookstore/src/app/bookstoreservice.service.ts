import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Book } from './book';

@Injectable({
  providedIn: 'root'
})
export class BookstoreserviceService {

  constructor(private _http:HttpClient) { }

  fetchBookList():Observable<any>{
    return this._http.get<any>('http://localhost:8080/getbooklist');
  }

  addBook(book:Book):Observable<any>{
    return this._http.post<any>('http://localhost:8080/addbook', book);
  }

  updateBook(book:Book):Observable<any>{
    return this._http.post<any>('http://localhost:8080/updatebook', book);
  }

  buyBook(book:Book):Observable<any>{
    return this._http.post<any>('http://localhost:8080/buybook', book);
  }

  fetchBookById(id:number):Observable<any>{
    return this._http.get<any>('http://localhost:8080/getbookbyid/' + id);
  }

  searchBookByName(name:string):Observable<any>{
    return this._http.get<any>('http://localhost:8080/getbookbyname/' + name);
  }
}
