import { Component, OnInit } from '@angular/core';
import { Book } from '../book';
import { Router, ActivatedRoute } from '@angular/router';
import { BookstoreserviceService } from '../bookstoreservice.service';

@Component({
  selector: 'app-buybook',
  templateUrl: './buybook.component.html',
  styleUrls: ['./buybook.component.css']
})
export class BuybookComponent implements OnInit {

  book = new Book();
  constructor(private _route:Router, 
              private _service:BookstoreserviceService,
              private _activitedRoute:ActivatedRoute) { }

  ngOnInit(): void { 
    let id = parseInt(this._activitedRoute.snapshot.paramMap.get('id'));
    this._service.fetchBookById(id).subscribe(
      data=>{
        console.log("Data recieved");
        this.book = data;
      },
      error=>console.log("Exception occured")
    )
  }

  buyBook(){
    this.book.quantity -= 1;
    this._service.buyBook(this.book).subscribe
    (
      data =>{
        console.log("Data added successfully");
        this._route.navigate(['booklist']);
      },
      error =>console.log("Error")
    )
    }
    
    
  gotolist() {
    this._route.navigate(['booklist']);
  }

}
